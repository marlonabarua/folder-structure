#!/usr/bin/env bash
set -e

source .env


helm repo add stardog-sa https://stardog-union.github.io/helm-chart-sa/

# create a licence secrets
kubectl -n stardog-ns create secret generic stardog-license --from-file stardog-license-key.bin=[DIRECTORY]/stardog-license-key.bin

helm upgrade -i stardog-helm-release -n stardog-ns --values cluster_values.yaml stardog-sa/stardog  --debug --timeout 5m 