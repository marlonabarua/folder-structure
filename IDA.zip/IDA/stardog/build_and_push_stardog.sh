#!/usr/bin/env bash 
set -e
source ../.env 


#adjust dockerfile to what you need. 

echo "Building image '${CONTAINER_REGISTRY_URL}/launchpad/${DOCKER_IMAGE_NAME}-launchpad:${VERSION}', and pushing to '$CONTAINER_REGISTRY_URL'"

#In case yu need to loging to Repository
#docker login stardog-stardog-apps.jfrog.io -u="${DOCKER_USERNAME}" -p="${DOCKER_PASSWORD}"

docker build -t ${CONTAINER_REGISTRY_URL}/stardog/${DOCKER_IMAGE_NAME}:${VERSION} . 
docker push ${CONTAINER_REGISTRY_URL}/stardog/${DOCKER_IMAGE_NAME}:${VERSION}
